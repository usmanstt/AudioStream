package com.example.audiostream.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.audiostream.R;
import com.example.audiostream.model.categoryitems;

import java.util.List;
import java.util.Locale;

public class CategoryItemRecyclerAdapter extends RecyclerView.Adapter<CategoryItemRecyclerAdapter.CategoryItemViewHolder> {

    private Context context;
    private List<categoryitems> categoryitemsList;

    public CategoryItemRecyclerAdapter(Context context, List<categoryitems> categoryitemsList) {
        this.context = context;
        this.categoryitemsList = categoryitemsList;
    }

    @NonNull
    @Override
    public CategoryItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new CategoryItemViewHolder(LayoutInflater.from(context).inflate(R.layout.category_row_items, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryItemViewHolder holder, int position) {
            holder.itemImage.setImageResource(categoryitemsList.get(position).getImageurl());
    }

    @Override
    public int getItemCount() {
        return categoryitemsList.size();
    }

    public static final class CategoryItemViewHolder extends RecyclerView.ViewHolder{

        ImageView itemImage;

        public CategoryItemViewHolder(@NonNull View itemView) {
            super(itemView);

            itemImage = itemView.findViewById(R.id.itemimage);
        }
    }

}
