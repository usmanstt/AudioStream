package com.example.audiostream.model;

public class categoryitems {

    //using image url here, setting it as an integer because we're picking up the imageurl from drawable.
    Integer imageId;
    Integer imageurl;

    public categoryitems(Integer imageId, Integer imageurl) {
        this.imageId = imageId;
        this.imageurl = imageurl;
    }

    public Integer getImageId() {
        return imageId;
    }

    public void setImageId(Integer imageId) {
        this.imageId = imageId;
    }

    public Integer getImageurl() {
        return imageurl;
    }

    public void setImageurl(Integer imageurl) {
        this.imageurl = imageurl;
    }
}
