package com.example.audiostream;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.audiostream.adapter.MainRecyclerAdapter;
import com.example.audiostream.model.Categories;
import com.example.audiostream.model.categoryitems;

import java.util.ArrayList;
import java.util.List;

public class homepage extends AppCompatActivity {

    RecyclerView mainCatRecycler;
    MainRecyclerAdapter mainrecycleAdapt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);



        //adding data to category item class

        List<categoryitems> categoryitemsList = new ArrayList<>();
        List<categoryitems> categoryitemsList2 = new ArrayList<>();
        List<categoryitems> categoryitemsList3 = new ArrayList<>();


        //adding to first category
        categoryitemsList.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList.add(new categoryitems(1, R.drawable.trackbg));

        //adding to second category
        categoryitemsList2.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList2.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList2.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList2.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList2.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList2.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList2.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList2.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList2.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList2.add(new categoryitems(1, R.drawable.trackbg));

        //adding to third category
        categoryitemsList3.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList3.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList3.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList3.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList3.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList3.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList3.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList3.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList3.add(new categoryitems(1, R.drawable.trackbg));
        categoryitemsList3.add(new categoryitems(1, R.drawable.trackbg));

        //adding dummy data to model class

        List<Categories> categoriesList = new ArrayList<>();
        categoriesList.add(new Categories("Top 10 Music Tracks", categoryitemsList));
        categoriesList.add(new Categories("Top 10 Podcasts", categoryitemsList2));
        categoriesList.add(new Categories("Top News Articles", categoryitemsList3));

        setMainCatRecycler(categoriesList);
    }

    private void setMainCatRecycler(List<Categories> categoriesList){
        mainCatRecycler = findViewById(R.id.main_recycle);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        mainCatRecycler.setLayoutManager(layoutManager);
        mainrecycleAdapt = new MainRecyclerAdapter( this, categoriesList);
        mainCatRecycler.setAdapter(mainrecycleAdapt);
    }
}