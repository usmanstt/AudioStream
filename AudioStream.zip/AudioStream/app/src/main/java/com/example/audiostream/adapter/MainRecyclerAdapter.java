package com.example.audiostream.adapter;

import android.content.Context;
import android.icu.text.Transliterator;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.audiostream.R;
import com.example.audiostream.model.Categories;
import com.example.audiostream.model.categoryitems;

import java.util.List;

public class MainRecyclerAdapter extends RecyclerView.Adapter<MainRecyclerAdapter.MainViewHolder>{

    private Context context;
    private List<Categories> categoryList;

    public MainRecyclerAdapter(Context context, List<Categories> categoryList) {
        this.context = context;
        this.categoryList = categoryList;
    }

    @NonNull
    @Override
    public MainViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MainViewHolder(LayoutInflater.from(context).inflate(R.layout.recycler_row_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MainViewHolder holder, int position) {
          holder.categoryTitle.setText(categoryList.get(position).getCategoryTitle());
          setCategoryItemRecycler(holder.catitemrecycler,categoryList.get(position).getCategoryitemsList());
    }

    @Override
    public int getItemCount() {
        return categoryList.size();
    }

    public static final class MainViewHolder extends RecyclerView.ViewHolder{

        TextView categoryTitle;
        RecyclerView catitemrecycler;

        public MainViewHolder(@NonNull View itemView) {
            super(itemView);

            categoryTitle = itemView.findViewById(R.id.cat_title);
            catitemrecycler = itemView.findViewById(R.id.catitemrecycler);
        }
    }
    private void setCategoryItemRecycler(RecyclerView recyclerView, List<categoryitems> categoryitemsList){
        CategoryItemRecyclerAdapter itemRecyclerAdapter = new CategoryItemRecyclerAdapter(context, categoryitemsList);
        recyclerView.setLayoutManager(new LinearLayoutManager(context, RecyclerView.HORIZONTAL, false));
        recyclerView.setAdapter(itemRecyclerAdapter);
    }
}
