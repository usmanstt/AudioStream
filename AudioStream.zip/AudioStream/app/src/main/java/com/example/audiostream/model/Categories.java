package com.example.audiostream.model;

import java.util.List;

public class Categories {

    String categoryTitle;
    List<categoryitems> categoryitemsList;

    public Categories(String categoryTitle, List<categoryitems> categoryitemsList) {
        this.categoryTitle = categoryTitle;
        this.categoryitemsList = categoryitemsList;
    }

    public List<categoryitems> getCategoryitemsList() {
        return categoryitemsList;
    }

    public void setCategoryitemsList(List<categoryitems> categoryitemsList) {
        this.categoryitemsList = categoryitemsList;
    }

    public String getCategoryTitle() {
        return categoryTitle;
    }

    public void setCategoryTitle(String categoryTitle) {
        this.categoryTitle = categoryTitle;
    }
}
